import pygame
from kliittyma import Kliittyma

if __name__ == "__main__":
    k = Kliittyma()
    k.run()
        